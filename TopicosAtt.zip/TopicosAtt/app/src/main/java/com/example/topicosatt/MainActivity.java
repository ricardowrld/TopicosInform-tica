package com.example.topicosatt;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
        public EditText input;
        int resultado = 0;

        protected void onCreate(Bundle savedInstanceState) {

            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_main);

            input = findViewById(R.id.editTxt);

    }

    public void FunSomar(View view) {
            resultado += Integer.parseInt(input.getText().toString());
            Toast.makeText(this, "Soma = " + resultado, Toast.LENGTH_SHORT).show();

    }

    public void Limpar(View view) {
            resultado = 0;
    }
}